import axios from "axios"

const host = "http://localhost:5000"
const productAPI = {
    get(){
        return axios.get(host + "/products") 
    },
    trend(){
        return axios.get(host + "/products_trend") 
    }
}
export default productAPI