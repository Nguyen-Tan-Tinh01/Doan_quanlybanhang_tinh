import { useState } from "react"
import { Card, CardTitle, CardText, Button } from "reactstrap"
import { Grid } from "@mui/material"

export default function Products() {

    const [data, setData] = useState([
        {
            name: "Thời Trang Nam",
            image: "https://cf.shopee.vn/file/687f3967b7c2fe6a134a2c11894eea4b_tn"
        },
        {
            name: "Thời Trang Nam",
            image: "https://cf.shopee.vn/file/687f3967b7c2fe6a134a2c11894eea4b_tn"
        }
    ])

    return (
        <Grid container p={2} spacing={2}>
            {data.map((value) => {
                return (
                    <Grid item>
                        <Card
                            body
                            className="my-2"
                            style={{
                                width: '12rem'
                            }}
                        >
                            <CardTitle>
                                <img src={value.image} width='150px' />
                            </CardTitle>
                            <CardText style={{ textAlign: 'center' }}>
                                {value.name}
                            </CardText>
                        </Card>
                    </Grid>
                )
            })
            }
        </Grid>
    )
}